<?php
/**
 * Creates a call for the method `yii\db\Migration::createTable()`
 *
 * @var string $table the name table
 * @var string $tableComment the comment table
 */
?>        $this->addCommentOnTable('<?= $table ?>', '<?= $tableComment ?>');
