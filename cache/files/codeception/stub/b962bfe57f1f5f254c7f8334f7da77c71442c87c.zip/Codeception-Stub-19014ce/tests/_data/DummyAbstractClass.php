<?php

declare(strict_types=1);

abstract class DummyAbstractClass
{
}